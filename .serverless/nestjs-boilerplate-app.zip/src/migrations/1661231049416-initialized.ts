import {MigrationInterface, QueryRunner} from "typeorm";

export class initialized1661231049416 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
