"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
var Role;
(function (Role) {
    Role["standard"] = "standard";
    Role["premium"] = "premium";
})(Role = exports.Role || (exports.Role = {}));
//# sourceMappingURL=role.enum.js.map