export declare class UsersDTO {
    email: string;
    address?: string;
    name?: string;
    password: string;
}
