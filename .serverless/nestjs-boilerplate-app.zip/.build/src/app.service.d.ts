export declare class AppService {
    getHello(): {
        status: number;
        content: {
            msg: string;
        };
    };
}
