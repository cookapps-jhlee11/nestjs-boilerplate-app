import { PostgresConnectionOptions } from 'typeorm/driver/postgres/PostgresConnectionOptions';
export declare const dbConfig: () => PostgresConnectionOptions;
declare const _default: PostgresConnectionOptions;
export default _default;
